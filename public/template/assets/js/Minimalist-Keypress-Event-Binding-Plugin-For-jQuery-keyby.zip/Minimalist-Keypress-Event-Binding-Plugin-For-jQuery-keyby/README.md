# keyby
Keyby is a Javascript library that makes it easier for you to bind keyboard shortcuts and key presses.
